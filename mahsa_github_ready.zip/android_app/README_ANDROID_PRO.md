Professional Android features: SQLCipher, SSO links, offline cache, roles, backups
