Room + SQLCipher snippet
