# Mahsa — Pharmacy Management Software (GitHub-ready)

This repository is a GitHub-ready complete project skeleton for Mahsa.
