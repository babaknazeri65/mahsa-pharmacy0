Build notes placeholder
