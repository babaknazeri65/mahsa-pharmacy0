# Mahsa desktop main placeholder
print('Mahsa')
